This is a plug-in for Thonny which lets you flash 
a BBC micro:bit with an IO .hex file to support using the micro:bit as
a sensor/output device. You need to install another module to make this 
useful. More info about Thonny: http://thonny.org

