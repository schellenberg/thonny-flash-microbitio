This is a plug-in for Thonny which adds BBC micro:bit IO support. In other words, it allows you to use your micro:bit sensors/leds/etc while writing Python programs that run on your host machine (Mac/Windows/Linux). The micro:bit is simply used as a sensor/output device. More info about Thonny: http://thonny.org


Plug-in installation and configuration guide: 
https://bitbucket.org/KauriRaba/thonny-microbit/wiki/installation-guide

Manual: https://bitbucket.org/KauriRaba/thonny-microbit/wiki/manual